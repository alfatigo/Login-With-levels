﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using SqlContent;

namespace WindowsFormsApp4
{
    public partial class LoginForm : Form
    {

        public static string codigo = "";
        

        public LoginForm()
        {
           
            InitializeComponent();
        }
     
      

        private void button1_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection("Data Source=AdministratorDB.mssql.somee.com;Initial Catalog=YoutDatabase;User IDIDHosting;Password=YourPasswordDataBase!");

            try
            {
                button1.BackColor = Color.Green;
                con.Open();
                MessageBox.Show("DataBase Working!");
            }
            catch
            {
                button1.BackColor = Color.Red;
                MessageBox.Show("Error The DataBase is down!");
            }

            finally
            {
                con.Close();
            }
           
        }

        private void Btn_Login_Click(object sender, EventArgs e)
        {
            
            try
            {


                string CMD = string.Format("Select*From Usuario Where Acoun_Usuario = '{0}' AND Password ='{1}'", text_acount.Text.Trim(), textBox1.Text.Trim());
                DataSet ds = Utilidades.Ejecutar(CMD);

               // codigo = ds.Tables[0].Rows[0]["Id_Usuario"].ToString().Trim();

                string cuenta = ds.Tables[0].Rows[0]["Acoun_Usuario"].ToString().Trim();
                string psd = ds.Tables[0].Rows[0]["Password"].ToString().Trim();

                if(cuenta== text_acount.Text.Trim() && psd == textBox1.Text.Trim())
                {
                    this.Hide();
                    if (Convert.ToBoolean(ds.Tables[0].Rows[0]["Status_User"])==true)
                    {
                      
                        var Form_Admin = new AdminForm();
                        Form_Admin.Show();
                    }
                    else
                    {
                        var normaluser = new UserNoAdmin();
                        normaluser.Show();
                    }
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show("Error!",ex.ToString());

            }
            
        }

      

     
   

        private void text_acount_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void BTN_SingUp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This option is not available");
            text_acount.Focus();
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
