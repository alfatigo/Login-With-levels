﻿using SqlContent;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApp4
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
           // onload();
            InitializeComponent();
        }


        public  void onload()
        {

            
        }


        private void AdminForm_Load(object sender, EventArgs e)
        {

            string cmd = "Select*From Usuario Where Id_Usuario = 1";
            DataSet Ds = Utilidades.Ejecutar(cmd);

            Txt_Id.Text = Ds.Tables[0].Rows[0]["Id_Usuario"].ToString().Trim();
            Txt_Name.Text = Ds.Tables[0].Rows[0]["Nom_Usuario"].ToString().Trim();
            Txt_UserName.Text = Ds.Tables[0].Rows[0]["Acoun_Usuario"].ToString().Trim();
            Txt_PSD.Text = Ds.Tables[0].Rows[0]["Password"].ToString().Trim();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void cLoseToolStripMenuItem_Click(object sender, EventArgs e)
        {
           // Application.Exit();
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Working...");
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
            //this.Close();
            //var Login_Menu = new LoginForm();
           // Login_Menu.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            var mainfrom = new LoginForm();
            mainfrom.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
